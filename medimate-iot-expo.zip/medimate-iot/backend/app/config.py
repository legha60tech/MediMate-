"""Configuration loaded from environment variables (and an optional backend/.env file)."""
import os
from pathlib import Path

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BACKEND_DIR / ".env")

DATABASE_URL = os.getenv("MEDIMATE_DATABASE_URL", f"sqlite:///{(BACKEND_DIR / 'medimate.db').as_posix()}")
# "simulation" (default) or "live". Live mode only reports itself as not implemented in this prototype.
DEVICE_MODE = os.getenv("MEDIMATE_DEVICE_MODE", "simulation").lower()
SEED_DEMO = os.getenv("MEDIMATE_SEED_DEMO", "true").lower() == "true"
ENABLE_DEMO_CLOCK = os.getenv("MEDIMATE_ENABLE_DEMO_CLOCK", "true").lower() == "true"
OVERDUE_GRACE_MINUTES = int(os.getenv("MEDIMATE_OVERDUE_GRACE_MINUTES", "30"))
DISPENSE_EARLY_MINUTES = int(os.getenv("MEDIMATE_DISPENSE_EARLY_MINUTES", "60"))
CORS_ORIGINS = [
    o.strip()
    for o in os.getenv("MEDIMATE_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
    if o.strip()
]
