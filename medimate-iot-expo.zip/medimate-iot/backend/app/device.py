"""Hardware abstraction layer.

Everything that could move a motor goes through a DeviceAdapter.
- SimulatedDeviceAdapter (default): runs in memory and reports simulated sensor results.
- MqttDeviceAdapter: documented stub for the future ESP32 integration. It never reports
  a connection and refuses every dispense command.
"""
from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone

from . import config


class DeviceError(Exception):
    """The device cannot accept or complete a request."""


def _real_utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _iso(dt: datetime | None) -> str | None:
    return dt.replace(tzinfo=timezone.utc).isoformat().replace("+00:00", "Z") if dt else None


class DeviceAdapter(ABC):
    mode: str = "unknown"

    @abstractmethod
    def is_connected(self) -> bool: ...

    @abstractmethod
    def test_connection(self) -> dict: ...

    @abstractmethod
    def get_status(self) -> dict: ...

    @abstractmethod
    def get_compartments(self) -> dict: ...

    @abstractmethod
    def request_dispense(self, command_id: str, compartment: int, dose_id: str) -> dict: ...

    @abstractmethod
    def poll_command(self, command_id: str) -> dict | None: ...

    @abstractmethod
    def stop(self, command_id: str) -> dict: ...

    @abstractmethod
    def send_emergency_alert(self, event_id: str) -> dict: ...

    @abstractmethod
    def configure_simulation(self, dispense_seconds=None, fail_next_dispense=None) -> None: ...


class SimulatedDeviceAdapter(DeviceAdapter):
    mode = "simulation"

    def __init__(self) -> None:
        self.device_id = "MM-SIM-0001"
        self.firmware = "sim-0.2.0"
        # Hardware-level compartment states (the "sensor" view). Compartment 4 is empty on purpose,
        # so the demo can show that an empty compartment is refused.
        self.compartments = {1: "ready", 2: "ready", 3: "low", 4: "empty"}
        self.dispense_seconds = 3.0
        self.fail_next = False
        self._active: dict[str, dict] = {}
        self.last_heartbeat = _real_utc_now()

    def is_connected(self) -> bool:
        return True

    def test_connection(self) -> dict:
        self.last_heartbeat = _real_utc_now()
        return {"ok": True, "message": "Simulated device responded. No physical hardware is involved."}

    def get_status(self) -> dict:
        self.last_heartbeat = _real_utc_now()  # simulated heartbeat, refreshed on each status poll
        return {
            "mode": self.mode,
            "connected": True,
            "deviceId": self.device_id,
            "firmware": self.firmware,
            "lastHeartbeat": _iso(self.last_heartbeat),
            "dispenseSeconds": self.dispense_seconds,
            "failNextDispense": self.fail_next,
        }

    def get_compartments(self) -> dict:
        return dict(self.compartments)

    def get_sensor_readings(self) -> dict:
        return {"compartments": dict(self.compartments), "note": "simulated readings"}

    def request_dispense(self, command_id: str, compartment: int, dose_id: str) -> dict:
        if compartment not in self.compartments:
            raise DeviceError(f"Compartment {compartment} does not exist on this device")
        state = self.compartments[compartment]
        if state in ("empty", "fault"):
            return {"status": "failed", "reason": f"Compartment {compartment} is {state}. Dispense refused."}
        if self.fail_next:
            self.fail_next = False
            return {"status": "failed", "reason": "Simulated jam: motor stalled (fault injected for testing)."}
        started = _real_utc_now()
        completes = started + timedelta(seconds=self.dispense_seconds)
        self._active[command_id] = {"compartment": compartment, "completes": completes}
        return {"status": "dispensing", "started": started, "completes": completes}

    def poll_command(self, command_id: str) -> dict | None:
        info = self._active.get(command_id)
        if info is None:
            return None  # unknown command (for example, after a server restart)
        if _real_utc_now() >= info["completes"]:
            del self._active[command_id]
            return {"status": "completed", "sensor": "simulated pill-drop sensor reports a drop (simulation only)"}
        return {"status": "dispensing"}

    def stop(self, command_id: str) -> dict:
        self._active.pop(command_id, None)
        return {"status": "stopped"}

    def send_emergency_alert(self, event_id: str) -> dict:
        return {
            "status": "simulated",
            "note": "SIMULATION: No real call or message was sent. A real build would use a GSM/LTE module or an authorised service here.",
        }

    def configure_simulation(self, dispense_seconds=None, fail_next_dispense=None) -> None:
        if dispense_seconds is not None:
            self.dispense_seconds = float(dispense_seconds)
        if fail_next_dispense is not None:
            self.fail_next = bool(fail_next_dispense)


class MqttDeviceAdapter(DeviceAdapter):
    """Stub for the future ESP32 link. See docs/hardware-integration.md."""

    mode = "live"

    def is_connected(self) -> bool:
        return False

    def test_connection(self) -> dict:
        return {"ok": False, "message": "Live MQTT adapter is not implemented in this prototype."}

    def get_status(self) -> dict:
        return {
            "mode": self.mode,
            "connected": False,
            "deviceId": "not-configured",
            "firmware": None,
            "lastHeartbeat": None,
            "dispenseSeconds": None,
            "failNextDispense": False,
            "reason": "Live MQTT adapter is not implemented. Dispensing is refused.",
        }

    def get_compartments(self) -> dict:
        return {}

    def request_dispense(self, command_id: str, compartment: int, dose_id: str) -> dict:
        raise DeviceError("Live hardware is not connected. Dispensing refused.")

    def poll_command(self, command_id: str) -> dict | None:
        return None

    def stop(self, command_id: str) -> dict:
        raise DeviceError("Live hardware is not connected.")

    def send_emergency_alert(self, event_id: str) -> dict:
        raise DeviceError("No live emergency channel is configured in this prototype.")

    def configure_simulation(self, dispense_seconds=None, fail_next_dispense=None) -> None:
        raise DeviceError("Simulation settings are only available in simulation mode.")


_adapter: DeviceAdapter | None = None


def get_adapter() -> DeviceAdapter:
    global _adapter
    if _adapter is None:
        _adapter = MqttDeviceAdapter() if config.DEVICE_MODE == "live" else SimulatedDeviceAdapter()
    return _adapter
